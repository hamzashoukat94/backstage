
# Status Enum

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `Available` |
| `Pending` |
| `Sold` |

