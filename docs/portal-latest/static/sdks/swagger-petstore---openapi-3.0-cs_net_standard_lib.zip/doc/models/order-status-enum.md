
# Order Status Enum

Order Status

## Enumeration

`OrderStatusEnum`

## Fields

| Name |
|  --- |
| `Placed` |
| `Approved` |
| `Delivered` |

