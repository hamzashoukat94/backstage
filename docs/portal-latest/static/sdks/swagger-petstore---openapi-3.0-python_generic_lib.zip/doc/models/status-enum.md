
# Status Enum

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `PENDING` |
| `SOLD` |

