
# Pet Image

## Structure

`PetImage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `int` | Optional | - |
| `mtype` | `string` | Optional | - |
| `message` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "code": 130,
  "type": "type0",
  "message": "message0"
}
```

