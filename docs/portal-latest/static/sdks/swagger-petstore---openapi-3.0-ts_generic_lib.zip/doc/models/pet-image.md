
# Pet Image

## Structure

`PetImage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `number \| undefined` | Optional | - |
| `type` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "code": 130,
  "type": "type0",
  "message": "message0"
}
```

