
# Order Status Enum

Order Status

## Enumeration

`OrderStatusEnum`

## Fields

| Name |
|  --- |
| `placed` |
| `approved` |
| `delivered` |

