
# Status Enum

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `available` |
| `pending` |
| `sold` |

