
# Pet Image

## Structure

`PetImage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `Integer` | Optional | - |
| `type` | `String` | Optional | - |
| `message` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "code": 130,
  "type": "type0",
  "message": "message0"
}
```

