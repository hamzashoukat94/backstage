
# Category

## Structure

`Category`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `name` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "id": 1,
  "name": "Dogs"
}
```

